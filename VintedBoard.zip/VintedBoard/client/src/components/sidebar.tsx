import { cn } from '@/lib/utils';

interface SidebarProps {
  selectedMonth: string;
  onMonthSelect: (month: string) => void;
  isOpen: boolean;
  onToggle: () => void;
}

const months = [
  { key: 'all', label: 'All Months' },
  { key: 'jan', label: 'January' },
  { key: 'feb', label: 'February' },
  { key: 'mar', label: 'March' },
  { key: 'apr', label: 'April' },
  { key: 'may', label: 'May' },
  { key: 'jun', label: 'June' },
  { key: 'jul', label: 'July' },
  { key: 'aug', label: 'August' },
  { key: 'sep', label: 'September' },
  { key: 'oct', label: 'October' },
  { key: 'nov', label: 'November' },
  { key: 'dec', label: 'December' },
];

export function Sidebar({ selectedMonth, onMonthSelect, isOpen }: SidebarProps) {
  return (
    <div className={cn(
      "bg-sidebar border-r border-sidebar-border w-64 flex-shrink-0 sidebar-transition",
      "fixed md:relative z-50 h-full",
      isOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
    )}>
      <div className="p-6 border-b border-sidebar-border">
        <h1 className="text-2xl font-bold text-sidebar-primary">
          <i className="fas fa-chart-line mr-2"></i>
          Sales Tracker
        </h1>
        <p className="text-sidebar-foreground text-sm mt-1 opacity-75">Vinted Dashboard</p>
      </div>
      
      <div className="p-4">
        <h2 className="text-sm font-semibold text-sidebar-foreground uppercase tracking-wider mb-4 opacity-75">
          Filter by Month
        </h2>
        <div className="space-y-2">
          {months.map((month) => (
            <button
              key={month.key}
              data-testid={`filter-month-${month.key}`}
              onClick={() => onMonthSelect(month.key)}
              className={cn(
                "w-full text-left px-3 py-2 rounded-md text-sm font-medium transition-colors",
                selectedMonth === month.key
                  ? "bg-sidebar-primary/20 text-sidebar-primary"
                  : "text-sidebar-foreground hover:bg-sidebar-accent/20 hover:text-sidebar-accent-foreground"
              )}
            >
              {month.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
