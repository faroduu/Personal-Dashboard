import { Item, ItemStatus } from '@/types/item';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface ItemsTableProps {
  items: Item[];
  onUpdateItemStatus: (id: string, status: ItemStatus) => void;
  onDeleteItem: (id: string) => void;
}

const getStatusClass = (status: ItemStatus) => {
  switch (status) {
    case 'listed':
      return 'status-listed';
    case 'for-money':
      return 'status-for-money';
    case 'sold':
      return 'status-sold';
    case 'delivered':
      return 'status-delivered';
    default:
      return '';
  }
};

export function ItemsTable({ items, onUpdateItemStatus, onDeleteItem }: ItemsTableProps) {
  if (items.length === 0) {
    return (
      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <div className="px-6 py-4 border-b border-border">
          <h3 className="text-lg font-semibold flex items-center">
            <i className="fas fa-table text-primary mr-2"></i>
            Items Tracker
            <span className="ml-2 text-sm text-muted-foreground" data-testid="text-items-count">
              (0 items)
            </span>
          </h3>
        </div>
        <div className="py-12 text-center">
          <i className="fas fa-box-open text-4xl text-muted-foreground mb-4"></i>
          <h3 className="text-lg font-medium text-foreground mb-2">No items yet</h3>
          <p className="text-muted-foreground">Add your first item or upload a CSV file to get started.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card border border-border rounded-lg overflow-hidden">
      <div className="px-6 py-4 border-b border-border">
        <h3 className="text-lg font-semibold flex items-center">
          <i className="fas fa-table text-primary mr-2"></i>
          Items Tracker
          <span className="ml-2 text-sm text-muted-foreground" data-testid="text-items-count">
            ({items.length} items)
          </span>
        </h3>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-muted/50">
            <tr>
              <th className="text-left py-3 px-6 text-sm font-medium text-muted-foreground uppercase tracking-wider">
                Item Name
              </th>
              <th className="text-left py-3 px-6 text-sm font-medium text-muted-foreground uppercase tracking-wider">
                Price
              </th>
              <th className="text-left py-3 px-6 text-sm font-medium text-muted-foreground uppercase tracking-wider">
                Status
              </th>
              <th className="text-left py-3 px-6 text-sm font-medium text-muted-foreground uppercase tracking-wider">
                Date Added
              </th>
              <th className="text-left py-3 px-6 text-sm font-medium text-muted-foreground uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {items.map((item) => (
              <tr key={item.id} className="hover:bg-muted/20 transition-colors">
                <td className="py-4 px-6 text-sm font-medium" data-testid={`text-item-name-${item.id}`}>
                  {item.name}
                </td>
                <td className="py-4 px-6 text-sm font-semibold text-primary" data-testid={`text-item-price-${item.id}`}>
                  £{item.price.toFixed(2)}
                </td>
                <td className="py-4 px-6">
                  <Select
                    value={item.status}
                    onValueChange={(value: ItemStatus) => onUpdateItemStatus(item.id, value)}
                  >
                    <SelectTrigger 
                      data-testid={`select-item-status-${item.id}`}
                      className={cn(
                        "px-3 py-1 rounded-full text-xs font-medium border-0 w-auto",
                        getStatusClass(item.status)
                      )}
                    >
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="listed">Listed</SelectItem>
                      <SelectItem value="for-money">For Money</SelectItem>
                      <SelectItem value="sold">Sold</SelectItem>
                      <SelectItem value="delivered">Delivered</SelectItem>
                    </SelectContent>
                  </Select>
                </td>
                <td className="py-4 px-6 text-sm text-muted-foreground" data-testid={`text-item-date-${item.id}`}>
                  {item.dateAdded}
                </td>
                <td className="py-4 px-6">
                  <Button
                    variant="ghost"
                    size="sm"
                    data-testid={`button-delete-item-${item.id}`}
                    onClick={() => onDeleteItem(item.id)}
                    className="text-red-400 hover:text-red-300 hover:bg-red-400/10 p-3 min-w-[44px] min-h-[44px] flex items-center justify-center"
                  >
                    <i className="fas fa-trash-alt"></i>
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
