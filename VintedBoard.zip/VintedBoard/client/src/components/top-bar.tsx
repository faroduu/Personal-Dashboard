interface TopBarProps {
  availableBalance: number;
  totalNetWorth: number;
  notificationCount: number;
  onToggleSidebar: () => void;
}

export function TopBar({ 
  availableBalance, 
  totalNetWorth, 
  notificationCount, 
  onToggleSidebar 
}: TopBarProps) {
  return (
    <header className="bg-card border-b border-border px-6 py-4 flex items-center justify-between">
      <button 
        data-testid="button-toggle-sidebar"
        onClick={onToggleSidebar}
        className="md:hidden text-muted-foreground hover:text-foreground p-3 min-w-[44px] min-h-[44px] flex items-center justify-center"
      >
        <i className="fas fa-bars text-xl"></i>
      </button>
      
      <div className="flex items-center space-x-8">
        <div className="flex items-center space-x-2">
          <div className="bg-primary/20 p-2 rounded-lg">
            <i className="fas fa-wallet text-primary text-lg"></i>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Available Balance</p>
            <p className="text-xl font-bold text-primary" data-testid="text-available-balance">
              £{availableBalance.toFixed(2)}
            </p>
          </div>
        </div>
        
        <div className="hidden sm:flex items-center space-x-2">
          <div className="bg-accent/20 p-2 rounded-lg">
            <i className="fas fa-chart-pie text-accent text-lg"></i>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Total Net Worth</p>
            <p className="text-xl font-bold text-accent" data-testid="text-total-net-worth">
              £{totalNetWorth.toFixed(2)}
            </p>
          </div>
        </div>
      </div>

      <div className="flex items-center space-x-4">
        <button className="relative p-2 text-muted-foreground hover:text-foreground">
          <i className="fas fa-bell text-lg"></i>
          {notificationCount > 0 && (
            <span 
              className="absolute -top-1 -right-1 bg-red-500 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center"
              data-testid="text-notification-count"
            >
              {notificationCount}
            </span>
          )}
        </button>
      </div>
    </header>
  );
}
