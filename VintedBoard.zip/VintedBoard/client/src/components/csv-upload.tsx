import { useRef } from 'react';
import { parseCSV, readFileAsText } from '@/lib/csv-parser';
import { ItemFormData } from '@/types/item';
import { useToast } from '@/hooks/use-toast';

interface CSVUploadProps {
  onImportItems: (items: ItemFormData[]) => void;
}

export function CSVUpload({ onImportItems }: CSVUploadProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.name.toLowerCase().endsWith('.csv')) {
      toast({
        title: "Invalid File Type",
        description: "Please select a CSV file",
        variant: "destructive"
      });
      return;
    }

    try {
      const csvText = await readFileAsText(file);
      const result = parseCSV(csvText);

      if (!result.success) {
        toast({
          title: "CSV Parse Error",
          description: result.error,
          variant: "destructive"
        });
        return;
      }

      if (result.data && result.data.length > 0) {
        const itemFormData = result.data.map(item => ({
          name: item.name,
          price: item.price,
          status: item.status
        }));
        
        onImportItems(itemFormData);
        
        toast({
          title: "Success",
          description: `Imported ${result.data.length} items successfully`,
        });
      } else {
        toast({
          title: "No Data",
          description: "No valid items found in CSV file",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to process CSV file",
        variant: "destructive"
      });
    }

    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <h3 className="text-lg font-semibold mb-4 flex items-center">
        <i className="fas fa-file-csv text-accent mr-2"></i>
        Import CSV File
      </h3>
      <div className="space-y-4">
        <div className="border-2 border-dashed border-border rounded-lg p-6 text-center hover:border-accent/50 transition-colors">
          <input
            ref={fileInputRef}
            type="file"
            id="csvUpload"
            data-testid="input-csv-upload"
            accept=".csv"
            className="hidden"
            onChange={handleFileChange}
          />
          <label htmlFor="csvUpload" className="cursor-pointer">
            <div className="flex flex-col items-center">
              <i className="fas fa-cloud-upload-alt text-4xl text-muted-foreground mb-3"></i>
              <p className="text-sm text-foreground font-medium">Click to upload CSV file</p>
              <p className="text-xs text-muted-foreground mt-1">Or drag and drop your file here</p>
            </div>
          </label>
        </div>
        <div className="text-xs text-muted-foreground">
          <p className="font-medium mb-1">CSV Format:</p>
          <p>Item Name, Price, Status</p>
          <p className="mt-2 text-secondary">
            <i className="fas fa-info-circle mr-1"></i>
            Status values: listed, for-money, sold, delivered
          </p>
        </div>
      </div>
    </div>
  );
}
