import { useState } from 'react';
import { ItemFormData, ItemStatus } from '@/types/item';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';

interface AddItemFormProps {
  onAddItem: (item: ItemFormData) => void;
}

export function AddItemForm({ onAddItem }: AddItemFormProps) {
  const [formData, setFormData] = useState<ItemFormData>({
    name: '',
    price: 0,
    status: 'listed'
  });
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim()) {
      toast({
        title: "Validation Error",
        description: "Item name is required",
        variant: "destructive"
      });
      return;
    }

    if (formData.price <= 0) {
      toast({
        title: "Validation Error", 
        description: "Price must be greater than 0",
        variant: "destructive"
      });
      return;
    }

    onAddItem(formData);
    setFormData({ name: '', price: 0, status: 'listed' });
    
    toast({
      title: "Success",
      description: "Item added successfully",
    });
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <h3 className="text-lg font-semibold mb-4 flex items-center">
        <i className="fas fa-plus-circle text-primary mr-2"></i>
        Add New Item
      </h3>
      <form onSubmit={handleSubmit}>
        <div className="space-y-4">
          <div>
            <Label htmlFor="itemName" className="block text-sm font-medium text-foreground mb-2">
              Item Name
            </Label>
            <Input
              id="itemName"
              data-testid="input-item-name"
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="Enter item name..."
              className="w-full"
            />
          </div>
          <div>
            <Label htmlFor="itemPrice" className="block text-sm font-medium text-foreground mb-2">
              Price (£)
            </Label>
            <Input
              id="itemPrice"
              data-testid="input-item-price"
              type="number"
              step="0.01"
              min="0"
              value={formData.price || ''}
              onChange={(e) => setFormData({ ...formData, price: parseFloat(e.target.value) || 0 })}
              placeholder="0.00"
              className="w-full"
            />
          </div>
          <div>
            <Label htmlFor="itemStatus" className="block text-sm font-medium text-foreground mb-2">
              Status
            </Label>
            <Select 
              value={formData.status} 
              onValueChange={(value: ItemStatus) => setFormData({ ...formData, status: value })}
            >
              <SelectTrigger data-testid="select-item-status" className="w-full">
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="listed">Listed</SelectItem>
                <SelectItem value="for-money">For Money</SelectItem>
                <SelectItem value="sold">Sold</SelectItem>
                <SelectItem value="delivered">Delivered</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button 
            type="submit" 
            data-testid="button-add-item"
            className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
          >
            <i className="fas fa-plus mr-2"></i>
            Add Item
          </Button>
        </div>
      </form>
    </div>
  );
}
