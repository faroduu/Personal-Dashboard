interface MetricsCardsProps {
  monthlyTotal: number;
  yearlyTotal: number;
  pendingDeliveries: number;
  activeItems: number;
}

export function MetricsCards({ 
  monthlyTotal, 
  yearlyTotal, 
  pendingDeliveries, 
  activeItems 
}: MetricsCardsProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      <div className="bg-card border border-border rounded-lg p-6 hover:shadow-lg transition-shadow">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground mb-1">Monthly Total</p>
            <p className="text-2xl font-bold text-primary" data-testid="text-monthly-total">
              £{monthlyTotal.toFixed(2)}
            </p>
            <p className="text-xs text-muted-foreground mt-1">Delivered this month</p>
          </div>
          <div className="bg-primary/20 p-3 rounded-full">
            <i className="fas fa-calendar-month text-primary text-lg"></i>
          </div>
        </div>
      </div>

      <div className="bg-card border border-border rounded-lg p-6 hover:shadow-lg transition-shadow">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground mb-1">Yearly Total</p>
            <p className="text-2xl font-bold text-accent" data-testid="text-yearly-total">
              £{yearlyTotal.toFixed(2)}
            </p>
            <p className="text-xs text-muted-foreground mt-1">Delivered this year</p>
          </div>
          <div className="bg-accent/20 p-3 rounded-full">
            <i className="fas fa-chart-line text-accent text-lg"></i>
          </div>
        </div>
      </div>

      <div className="bg-card border border-border rounded-lg p-6 hover:shadow-lg transition-shadow">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground mb-1">Notifications</p>
            <p className="text-2xl font-bold text-secondary" data-testid="text-pending-deliveries">
              {pendingDeliveries}
            </p>
            <p className="text-xs text-muted-foreground mt-1">Waiting for delivery</p>
          </div>
          <div className="bg-secondary/20 p-3 rounded-full">
            <i className="fas fa-clock text-secondary text-lg"></i>
          </div>
        </div>
      </div>

      <div className="bg-card border border-border rounded-lg p-6 hover:shadow-lg transition-shadow">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground mb-1">Active Items</p>
            <p className="text-2xl font-bold text-orange" data-testid="text-active-items">
              {activeItems}
            </p>
            <p className="text-xs text-muted-foreground mt-1">Currently listed</p>
          </div>
          <div className="bg-orange/20 p-3 rounded-full">
            <i className="fas fa-tag text-orange text-lg"></i>
          </div>
        </div>
      </div>
    </div>
  );
}
