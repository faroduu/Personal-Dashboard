import { useState, useMemo } from 'react';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { Item, ItemFormData, ItemStatus } from '@/types/item';
import { Sidebar } from '@/components/sidebar';
import { TopBar } from '@/components/top-bar';
import { MetricsCards } from '@/components/metrics-cards';
import { AddItemForm } from '@/components/add-item-form';
import { CSVUpload } from '@/components/csv-upload';
import { ItemsTable } from '@/components/items-table';

export default function Dashboard() {
  const [items, setItems] = useLocalStorage<Item[]>('vinted-items', []);
  const [selectedMonth, setSelectedMonth] = useState('all');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const filteredItems = useMemo(() => {
    if (selectedMonth === 'all') return items;
    
    const monthNames = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 
                       'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];
    const monthIndex = monthNames.indexOf(selectedMonth);
    
    if (monthIndex === -1) return items;
    
    return items.filter(item => {
      const itemDate = new Date(item.dateAdded);
      return itemDate.getMonth() === monthIndex;
    });
  }, [items, selectedMonth]);

  const metrics = useMemo(() => {
    const currentDate = new Date();
    const currentMonth = currentDate.getMonth();
    const currentYear = currentDate.getFullYear();

    const deliveredItems = items.filter(item => item.status === 'delivered');
    const soldItems = items.filter(item => item.status === 'sold');
    
    const monthlyDelivered = deliveredItems.filter(item => {
      const itemDate = new Date(item.dateAdded);
      return itemDate.getMonth() === currentMonth && itemDate.getFullYear() === currentYear;
    });

    const yearlyDelivered = deliveredItems.filter(item => {
      const itemDate = new Date(item.dateAdded);
      return itemDate.getFullYear() === currentYear;
    });

    const pendingDeliveries = soldItems.length;
    const activeItems = items.filter(item => item.status === 'listed').length;

    return {
      availableBalance: deliveredItems.reduce((sum, item) => sum + item.price, 0),
      totalNetWorth: items.reduce((sum, item) => sum + item.price, 0),
      monthlyTotal: monthlyDelivered.reduce((sum, item) => sum + item.price, 0),
      yearlyTotal: yearlyDelivered.reduce((sum, item) => sum + item.price, 0),
      pendingDeliveries,
      activeItems,
      notificationCount: pendingDeliveries
    };
  }, [items]);

  const addItem = (itemData: ItemFormData) => {
    const newItem: Item = {
      id: `item-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      name: itemData.name,
      price: itemData.price,
      status: itemData.status,
      dateAdded: new Date().toISOString().split('T')[0]
    };
    
    setItems(prevItems => [...prevItems, newItem]);
  };

  const importItems = (itemsData: ItemFormData[]) => {
    const newItems: Item[] = itemsData.map((itemData, index) => ({
      id: `csv-${Date.now()}-${index}`,
      name: itemData.name,
      price: itemData.price,
      status: itemData.status,
      dateAdded: new Date().toISOString().split('T')[0]
    }));
    
    setItems(prevItems => [...prevItems, ...newItems]);
  };

  const updateItemStatus = (id: string, status: ItemStatus) => {
    setItems(prevItems => 
      prevItems.map(item => 
        item.id === id ? { ...item, status } : item
      )
    );
  };

  const deleteItem = (id: string) => {
    setItems(prevItems => prevItems.filter(item => item.id !== id));
  };

  return (
    <div className="flex h-screen overflow-hidden bg-background text-foreground">
      <Sidebar
        selectedMonth={selectedMonth}
        onMonthSelect={setSelectedMonth}
        isOpen={sidebarOpen}
        onToggle={() => setSidebarOpen(!sidebarOpen)}
      />

      <div className="flex-1 flex flex-col overflow-hidden">
        <TopBar
          availableBalance={metrics.availableBalance}
          totalNetWorth={metrics.totalNetWorth}
          notificationCount={metrics.notificationCount}
          onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
        />

        <main className="flex-1 overflow-auto p-6">
          <MetricsCards
            monthlyTotal={metrics.monthlyTotal}
            yearlyTotal={metrics.yearlyTotal}
            pendingDeliveries={metrics.pendingDeliveries}
            activeItems={metrics.activeItems}
          />

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <AddItemForm onAddItem={addItem} />
            <CSVUpload onImportItems={importItems} />
          </div>

          <ItemsTable
            items={filteredItems}
            onUpdateItemStatus={updateItemStatus}
            onDeleteItem={deleteItem}
          />
        </main>
      </div>
    </div>
  );
}
