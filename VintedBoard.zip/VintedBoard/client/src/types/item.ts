export type ItemStatus = 'listed' | 'for-money' | 'sold' | 'delivered';

export interface Item {
  id: string;
  name: string;
  price: number;
  status: ItemStatus;
  dateAdded: string;
}

export interface ItemFormData {
  name: string;
  price: number;
  status: ItemStatus;
}
