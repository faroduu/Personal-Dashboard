import { Item, ItemStatus } from '@/types/item';

export interface CSVParseResult {
  success: boolean;
  data?: Item[];
  error?: string;
}

export function parseCSV(csvText: string): CSVParseResult {
  try {
    const lines = csvText.trim().split('\n');
    
    if (lines.length === 0) {
      return { success: false, error: 'CSV file is empty' };
    }

    const items: Item[] = [];
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;
      
      const columns = line.split(',').map(col => col.trim().replace(/^["']|["']$/g, ''));
      
      if (columns.length < 3) {
        return { success: false, error: `Line ${i + 1}: Invalid format. Expected: Item Name, Price, Status` };
      }

      const [name, priceStr, status] = columns;
      
      if (!name) {
        return { success: false, error: `Line ${i + 1}: Item name is required` };
      }

      const price = parseFloat(priceStr);
      if (isNaN(price) || price < 0) {
        return { success: false, error: `Line ${i + 1}: Invalid price "${priceStr}"` };
      }

      const validStatuses: ItemStatus[] = ['listed', 'for-money', 'sold', 'delivered'];
      const normalizedStatus = status.toLowerCase().replace(/\s+/g, '-') as ItemStatus;
      
      if (!validStatuses.includes(normalizedStatus)) {
        return { success: false, error: `Line ${i + 1}: Invalid status "${status}". Must be one of: listed, for-money, sold, delivered` };
      }

      items.push({
        id: `csv-${Date.now()}-${i}`,
        name,
        price,
        status: normalizedStatus,
        dateAdded: new Date().toISOString().split('T')[0]
      });
    }

    return { success: true, data: items };
  } catch (error) {
    return { success: false, error: 'Failed to parse CSV file' };
  }
}

export function readFileAsText(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => resolve(e.target?.result as string);
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsText(file);
  });
}
