eBay Finance Dashboard
=======================

How to Use:
-----------
1. Open `dashboard.html` in any modern web browser.
2. Upload the provided `cleaned_ebay_report.csv` file.
3. View your total sales, costs, and net profit.
4. A chart visualizes your summary.
5. Click "Export Summary" to download a text version of the report.

Works 100% offline.

Optional:
---------
You can upload this folder to GitHub and enable GitHub Pages to host it as a website.

Enjoy!
